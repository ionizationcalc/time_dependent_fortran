//#include "../copyright.h"
/*============================================================================*/
/*! \file nei_calc.c
 *  \brief Non-equilibrium calculation routines.
 *
 * PURPOSE: Perform NEI calcualtions using Eigenvalue method.
 *
 * REFERENCE: Shen, Raymond & Murphy, A&C, 2015.
 *
 * Update:
 *  2016-11-09:
 *  Initialization.
 *  2016-11-23
 *  Bus fixed in nei_two_step: unit of dt_c in advance_eigenmethod.
 *  2018-01-18
 *  Use Passive Scalars and perform Operator split NEI, 1st order.
 *  2019-11-12
 *  Add switch for sub-loops.
 *  2020-04-15
 *  Add cooling function.
 *  2021-04-08
 *  Develop version.
 *  2021-04-12
 *  V0 using intel MKL.
 */

/*============================================================================*/
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mkl.h"
#include "libnei_calc.h"
/*==============================================================================
 * PRIVATE VARIALBES AND FUNCTION PROTOTYPES:
 *============================================================================*/
/* NEI calc elements list */
#define elemmax 31
int nelem, *elem_list, *ion_sindex_list;

/* NEI constant */
double CONCE_MINIMUM = 0;
double TENEI_MINIMUM = 1.0e4; // (unit: K. The minimum Te in NEI calculations)

/* eigentables */
struct eigen_strc {
  int nte;
  int natom;
  double *telist;
  double **eqis;
  double **evals;
  double ***evect;
  double ***evect_invers;
};
struct eigen_strc etb[elemmax];
double dte_table;

/* ---------------------------------------------------------------------------*/
/* cooling tables */
/* ---------------------------------------------------------------------------*/
// Define table structure
struct rlelem_strc
{
  int natom; // atom number of this element
  int nte;  // temperature grid nodes
  double abundance; // abundance of this element
  double *temperature; // temperature grid
  double *rate_ei; // the loss rate with ni in EI cases
  double *rate_nei; // the loss rate with ni in NEI cases
  double **eifraction; // ion fractions in EI cases
  double **rate2d; // the loss rate without abundance and ion fraction
};

// Table grid constant
const double const_dlogte_grid = 0.01;
const double const_dlogte_low = 4.0;

// Includes 10 elements in cooling table:
//   {'h', 'he', 'c', 'n', 'o', 'ne', 'mg', 'si', 's', 'fe'}
const int n_coolingelem = 10;
const int natom_cooling_list[10] = {1,2,6,7,8,10,12,14,16,26};
char *coolingelem_list[] = {"h","he","c","n","o","ne","mg","si","s","fe"};
struct rlelem_strc rlrate[10];

// Cooling rate at each cell
double *qtarray; // sum of cooling function for EI cases. 


/* Ion functions */
void ionic_bc(const int is, const int ie, 
    const int js, const int je, 
    const int ks, const int ke);


/* New functinos */
void ini_table(char str_natomlist[],
               char ionrec_table_datapath[],
               char cooling_table_datapath[],
               const int n_scalar); 
void read_eigentb(char ionrec_table_datapath[]);
void sub_read_rltable(char cooling_table_datapath[]);
void ini_ionfraction(const int npoints, const double te_k_list[],
                              double **conce_out);
void nei_advance(const int npoints,
                     const int nstates_total,
                     const double te_k_pre[],
                     const double te_k_cur[],
                     const double ne_cm_pre[],
                     const double ne_cm_cur[],
                     double **conce_in,
                     const double dt,
                     double **conce_out);
void qtcell_nei(const int npoints,
                       const double te_k_list[],
                       double **conce_in,
                       double *qtcell);
double func_qt_ei(const double te);


/*=========================== PUBLIC FUNCTIONS ===============================*/
void ini_table(char str_natomlist[],
               char ionrec_table_datapath[],
               char cooling_table_datapath[],
               const int n_scalar)
{
  /* Set elemlist and ionindexlist */
  elem_list = (int*)calloc(elemmax, sizeof(int));
  ion_sindex_list = (int*)calloc(elemmax, sizeof(int));

  /* Read atomic information from input file */
  const char delim[1] = ",";
  char *token;
  int iatom, nstat;
  int iion, nstat_numb;

  /* Get atomic index to be computed */
  iatom = 0;
  token = strtok(str_natomlist, delim);
  elem_list[iatom] = atoi(token);
  iatom = iatom + 1;
  while( token != NULL ) {
    token = strtok(NULL, delim);
    if (token != NULL) {
      elem_list[iatom] = atoi(token);
      iatom = iatom + 1;
    }
  }
  nelem = iatom;
  
  nstat_numb = 0;
  int ions_index = 0;
  for (iatom=0; iatom<nelem; iatom++) {
    ion_sindex_list[iatom] = ions_index;
    nstat = elem_list[iatom] + 1;
    nstat_numb = nstat_numb + nstat;
    ions_index = ions_index + nstat;
    //printf("Loading Ielem=%d, Natom=%d, Nstat=%d, Ion_sindex=%d\n", iatom, elem_list[iatom], nstat, ion_sindex_list[iatom]);
  }
  
  /* Check configuration and input */
  if (nstat_numb != n_scalar) {
    printf("NSCALARS=%d, and nstat_numb=%d\n", n_scalar, nstat_numb);
    exit(0);
  }

  /* (2) Set table structure*/
  // Ionization/recombination table
  read_eigentb(ionrec_table_datapath);
  
  // Radiative cooling table
  sub_read_rltable(cooling_table_datapath);
}

/*----------------------------------------------------------------------------
  Name:
    ini_ionfraction
  Purpose:
    Return ion fractions at Te
  Input:
    npoints: number of sample points
    te_k_list: temperature list, 1d array, in unit of K;
  Output:
    conce_out: ion fractions, 2D[npoints, nstates_total]
*/
void ini_ionfraction(const int npoints, const double te_k_list[],
                              double **conce_out)
{
  // define output array
  int ielem, natom, nstates_total;
  int ipo, iatom, ion, iion;
  int index_te_in_table;

  nstates_total = 0;
  for (ielem =0; ielem < nelem; ielem++) {
    natom = elem_list[ielem];
    nstates_total += natom + 1; 
  }

  // Calculate ion fraction at each te point for all chosen elements
  // Get dte_table
  int nte = etb[elem_list[0]-1].nte;
  double teslog10_table = log10(etb[elem_list[0]-1].telist[0]);
  double teelog10_table = log10(etb[elem_list[0]-1].telist[nte-1]);
  dte_table =  (teelog10_table - teslog10_table)/(nte-1);
  //printf("dte_table=%f\n", dte_table);

  // enter telist 
  for (ipo = 0; ipo < npoints; ipo++) {
    // te index in ion/rec tables
    index_te_in_table = (int)((log10(te_k_list[ipo]) - teslog10_table + 0.5*dte_table)/dte_table);
    //printf("ipo=%d, Te=%.7e(K), index_te=%d\n", ipo, te_k_list[ipo], index_te_in_table);

    // enter element loops
    for (ielem =0; ielem < nelem; ielem++) {
      natom = elem_list[ielem];
      // the relative index of natom in etb table for C format (start from ZERO)
      int iatom = natom - 1; 
      for (ion = 0; ion < natom+1; ion++) {
        // set the relative index in total states list
        iion = ion + ion_sindex_list[ielem];
        // apply the conce_min insteady of negative values.
        conce_out[ipo][iion] = etb[iatom].eqis[index_te_in_table][ion];
      }
    }
  }
  return;
}

/*----------------------------------------------------------------------------
  Name: 
    nei_advance
  Purpose:
    One-step time advance
  Input:
    npoints: number of total sampling points
    nstates_total: number of total ions for all elements
    te_k_pre: temperatue at time_0, 1D array, in unit of K
    te_k_cur: temperatue at time_0+dt, 1D array, in unit of K
    ne_cm_pre: density at time_0, 1D array, in unit of cm^-3
    ne_cm_cur: density at time_0+dt, 1D array, in unit of cm^-3
    conce_in: ion fractions at time_0, 2D array [npoints, nstates]
    dt: time-step, in unit of s
  Output:
    conce_out: ion fractions at time_0+dt, 2D array [npoints, nstates]
  Update:
    2021-04-09
    2021-04-10
    2021-04-13
  ---------------------------------------------------------------------------*/
void nei_advance(const int npoints,
                     const int nstates_total,
                     const double te_k_pre[],
                     const double te_k_cur[],
                     const double ne_cm_pre[],
                     const double ne_cm_cur[],
                     double **conce_in,
                     const double dt,
                     double **conce_out)
{
  // a. define output array
  int ielem, natom;
  int ipo, iatom, ion, iion;
  int index_te, index_te_pre, index_te_cur, nstat;
  double *conce_pre, *conce_nxt;
  //double **conce_out;
  
  //conce_out = (double**)calloc(npoints, sizeof(double*));
  //for (ipo = 0; ipo < npoints; ipo++) {
  //  conce_out[ipo] = (double*)calloc(nstates_total, sizeof(double));
  //}

  // b. table information
  int nte_table = etb[elem_list[0]-1].nte;
  double teslog10_table = log10(etb[elem_list[0]-1].telist[0]);
  double dte_table = (log10(etb[elem_list[0]-1].telist[nte_table-1]) - teslog10_table)/(nte_table - 1);

  // c. Enter the element loops
  // --------------------------
  double ne_c, te_c;
  for (ielem=0; ielem<nelem; ielem++) {
    natom = elem_list[ielem];
    iatom = natom - 1;
    nstat = natom + 1;

    /* c(1) Eigenmatrix and eigenvalue methods */
    conce_pre = (double*)calloc(nstat, sizeof(double));
    conce_nxt = (double*)calloc(nstat, sizeof(double));

    double **diagona_vec;
    diagona_vec = (double**)calloc(nstat, sizeof(double*));
    for (ion = 0; ion < nstat; ion++) {
      diagona_vec[ion] = (double*)calloc(nstat, sizeof(double));
    }

    double *matrixA, *matrixC, *matrixD;
    double *evect, *evect_invers;
    double *f0, *f1;
    int m, n, p;
    m = nstat, p = nstat, n = nstat;
      
    matrixA = (double *)mkl_malloc( m*p*sizeof( double ), 64 );
    matrixC = (double *)mkl_malloc( m*n*sizeof( double ), 64 );
    matrixD = (double *)mkl_malloc( m*n*sizeof( double ), 64 );
    f0 = (double *)mkl_malloc( nstat*sizeof( double ), 64 );
    f1 = (double *)mkl_malloc( nstat*sizeof( double ), 64 );
    evect = (double *)mkl_malloc( p*n*sizeof( double ), 64 );
    evect_invers = (double *)mkl_malloc( p*n*sizeof( double ), 64 );

    // c(2) Enter the sampling points loop
    // ----------------------------------- 
    for (ipo = 0; ipo < npoints; ipo++) {

      // c(2).0 Prepare conce_pre
      for (ion = 0; ion < nstat; ion++) {
        iion = ion + ion_sindex_list[ielem];
        conce_pre[ion] = conce_in[ipo][iion];
      }
			
      // c(2).1 Estimate sub-loops
      index_te_pre = (int)((log10(te_k_pre[ipo]) - teslog10_table + 0.5*dte_table)/dte_table);
      index_te_cur = (int)((log10(te_k_cur[ipo]) - teslog10_table + 0.5*dte_table)/dte_table);
      int n_subtime = (int)(fmax(fabs(index_te_cur - index_te_pre), 1)); // MUST >= 1
      int isub, isign;
      double dne_sub, dte_sub, dt_sub;
      
      dne_sub = (ne_cm_cur[ipo] - ne_cm_pre[ipo])/n_subtime;
      dte_sub = (te_k_cur[ipo]  - te_k_pre[ipo])/n_subtime;
      dt_sub = dt/n_subtime;

      // c(2).2 Enter the time-advance sub-loop (and single step as well)
      for (isub = 0; isub < n_subtime; isub++) {

        // get index(te_c) and ne_c in the subloop
        ne_c = ne_cm_pre[ipo] + dne_sub*(isub+0.5);
        te_c = te_k_pre[ipo]  + dte_sub*isub;
        index_te = (int)((log10(te_c) - teslog10_table + 0.5*dte_table)/dte_table);

        // Advance dt_sub using eigenvalue methods
        // Load eigentable pieces
        int ion, jon;
        int kk = 0;
        for (ion = 0; ion < nstat; ion++) {
          for (jon = 0; jon < nstat; jon++) {
            evect[kk] = etb[iatom].evect[index_te][jon][ion];
            evect_invers[kk] = etb[iatom].evect_invers[index_te][jon][ion];
            kk += 1;
          }
        }
        
        // temperary diagonamatrix
        for (ion = 0; ion < nstat; ion++) {
          diagona_vec[ion][ion] = exp(etb[iatom].evals[index_te][ion]*dt_sub*ne_c);
        }
        
        // (a) get matrix_1
        kk = 0;
        for (ion=0; ion<nstat; ion++) {
          for (jon=0; jon<nstat; jon++) {
            matrixA[kk] = diagona_vec[ion][jon];
            kk += 1;
          }
        }
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, 
                m, n, p, 1.0, matrixA, p, evect, n, 0.0, matrixC, n);

        // (b) get matrix_2
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, 
                m, n, p, 1.0, evect_invers, p, matrixC, n, 0.0, matrixD, n);
        
        // (c) get ion fractions
        for (ion=0; ion<nstat; ion++) {
          f0[ion] = conce_pre[ion];
        }
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                1, n, p, 1.0, f0, p, matrixD, n, 0.0, f1, n);
        
        // (d) Update to nxt and pre
        for (ion = 0; ion <= natom; ion++) {
          //conce_nxt[ion] = fmax(f1[ion], CONCE_MINIMUM);
					conce_nxt[ion] = f1[ion];
          conce_pre[ion] = f1[ion];
        }

        // (e) Check results
				//double sum_conce_nxt = 0.0;
        //for (ion = 0; ion <= natom; ion++) {
				//	sum_conce_nxt += conce_nxt[ion];
        //}
				//printf("ipo=%d(isub=%d), te_c=%.3e, sum_nxt(%d)=%.13f\n", ipo, isub, te_c, sum_conce_nxt, natom);

      } // End for sub-time-advance

      // c(2).3 Update to conce_out
      for (ion = 0; ion < nstat; ion++) {
        iion = ion + ion_sindex_list[ielem];
        conce_out[ipo][iion] = conce_nxt[ion];
      }
    
    } // End for i-point loop  

    // Free the matrix memory
    mkl_free(evect_invers);
    mkl_free(evect);
    mkl_free(f1);
    mkl_free(f0);
    mkl_free(matrixD);
    mkl_free(matrixC);
    mkl_free(matrixA);
    for (ion = 0; ion < nstat; ion++) {
      free(diagona_vec[ion]);
    }
    free(diagona_vec);
    free(conce_nxt);
    free(conce_pre);
	
  } // End for i-element loop

  return;
}

/*----------------------------------------------------------------------------
  Name: 
    qtcell_nei
  Purpose:
    Calculate cooling functions Q(T) in NEI cases
  Input:
    npoints: number of total sampling points
    te_k_list: temperatue at time_0, 1D array, in unit of K
    conce_in: ion fraction for chosen elements, 2D array [npoints, nstates_total]
  Output:
    qtcell: Q(t), 1D array [npoints]
  Notice:
    Includes all 10 abandant elements in solar corona
  Update:
    2021-04-10
    2021-04-11
    2021-04-13: passing 
  ---------------------------------------------------------------------------*/
void qtcell_nei(const int npoints,
                       const double te_k_list[],
                       double **conce_in,
                       double *qtcell)
{
  // Define variables
  int ielem, i, iion, ion, nstat;
  double rate_l, rate_r, rate_ei, rate_nei;
  double te_c;
  static double conce[32], rate_ion[32];

  // EI Qt function
  for (i = 0; i < npoints; i++) {
    qtcell[i] = func_qt_ei(te_k_list[i]);
  }
  
  // Enter the element loop
  int ielem_cool;
  for (ielem = 0; ielem < nelem; ielem++) {
    nstat = elem_list[ielem] + 1;

    // Get icooling index of NEI element in cooling table
    for (i = 0;i < n_coolingelem; i++) {
      if (elem_list[ielem] == natom_cooling_list[i]) {
        ielem_cool = i;
      }
    }
    //printf("icooling_index[%d]=%d\n", ielem, ielem_cool);

    // Enter the i-loop, and update NEI Qt for the current element
    for (i = 0; i < npoints; i++) {

      // 0. Temperature, and define the interpolation ratio based on Temerature
      //  get the current temperature (K) on this cell */
      te_c = te_k_list[i];

      //  get ratio
      int ite_l = (int)((log10(te_c) - const_dlogte_low)/const_dlogte_grid);
      int ite_r = ite_l+1;
      double ratio = (log10(te_c) - log10(rlrate[0].temperature[ite_l]))
        /(log10(rlrate[ielem_cool].temperature[ite_r]) - log10(rlrate[0].temperature[ite_l]));

      //
      // 1a. Read EI coolingrate:
      //
      rate_l = rlrate[ielem_cool].rate_ei[ite_l];
      rate_r = rlrate[ielem_cool].rate_ei[ite_r];
      rate_ei = ratio*(rate_r - rate_l) + rate_l;

      //
      // 1b. Calculate NEI coolingrate: switch_calc_elemrate[.] = 1
      //
      // get conce from ion_mesh
      for (ion = 0; ion < nstat; ion++) {
        iion = ion + ion_sindex_list[ielem];
        conce[ion] = conce_in[i][iion];
      }

      for (iion=0;iion<nstat;iion++) {
        rate_l = rlrate[ielem_cool].rate2d[iion][ite_l];
        rate_r = rlrate[ielem_cool].rate2d[iion][ite_r];
        rate_ion[iion] = ratio*(rate_r - rate_l) + rate_l;
      }

      // Summerize all ion states
      rate_nei = 0;
      for (iion=0;iion<nstat;iion++) {
        rate_nei += rate_ion[iion]*conce[iion];
      }
      // Include abundance
      rate_nei *= rlrate[ielem_cool].abundance;  
      
      //	
      // 1c. update rate of the chosen element
      // 
      qtcell[i] = qtcell[i] - rate_ei + rate_nei;
    }
  }
  return;
}

/*----------------------------------------------------------------------------*/
void read_eigentb(char ionrec_table_datapath[])
{
  FILE *fp;
  char filename[300];
  char* nei_datapath;

  int i,j,k,kk;
  int ielem, iatom, iion;
  /* local temperary variables */
  int nte_c, natom_c;
  double temp;

  /* Get NEI table path */
  //nei_datapath = par_gets("NEI", "nei_datapath");
  
  /* Enter the main loop */
  for (ielem = 0; ielem < nelem; ielem++) {
    // The relative Index of element in tables
    iatom = elem_list[ielem] - 1;

    /* open file*/
    sprintf(filename, "%s%d.dat", ionrec_table_datapath, iatom+1);

    fp = fopen(filename, "r");

    /* read nte*/
    fscanf(fp, "%d", &nte_c);
    etb[iatom].nte = nte_c;

    /* read natom */
    fscanf(fp, "%d", &natom_c);
    etb[iatom].natom = natom_c;
    int nstat = natom_c + 1;

    /* read te_arr */
    etb[iatom].telist = (double*)calloc(nte_c, sizeof(double));
    ////etb[iatom].telist = (double *)calloc_1d_array(nte_c, sizeof(double));
    for (j = 0; j < nte_c; j++) {
      fscanf(fp, "%lf", &temp);
      etb[iatom].telist[j] = temp;
    }

    /* read eqistate */
    //etb[iatom].eqis = (double **)calloc_2d_array(nte_c, nstat, sizeof(double));
    etb[iatom].eqis = (double **)calloc(nte_c, sizeof(double*));
    for (j = 0; j < nte_c; j++) {
      etb[iatom].eqis[j] = (double *)calloc(nstat, sizeof(double));
    }
    for (i = 0; i < nstat; i++) {
      for (j = 0; j < nte_c; j++) {
        fscanf(fp, "%lf", &temp);
        etb[iatom].eqis[j][i] = temp;
      }
    }

    /* read eigenvalues */
    //etb[iatom].evals = (double **)calloc_2d_array(nte_c, nstat, sizeof(double));
    etb[iatom].evals = (double **)calloc(nte_c, sizeof(double*));
    for (j = 0; j < nte_c; j++) {
      etb[iatom].evals[j] = (double *)calloc(nstat, sizeof(double));
    }
    for (i = 0; i < nstat; i++) {
      for (j = 0; j < nte_c; j++) {
        fscanf(fp, "%lf", &temp);
        etb[iatom].evals[j][i] = temp;
      }
    }

    /* read eigenvector */
    //etb[iatom].evect = (double ***)calloc_3d_array(nte_c, nstat, nstat, sizeof(double));
    etb[iatom].evect = (double ***)calloc(nte_c, sizeof(double**));
    for (k = 0; k < nte_c; k++) {
      etb[iatom].evect[k] = (double **)calloc(nstat, sizeof(double*));
      for (j = 0; j < nstat; j++) {
        etb[iatom].evect[k][j] = (double *)calloc(nstat, sizeof(double));
      }
    }
    for (i = 0; i < nstat; i++) {
      for (j = 0; j < nstat; j++) {
        for (k = 0; k < nte_c; k++) {
          fscanf(fp, "%lf", &temp);
          etb[iatom].evect[k][j][i] = temp;
        }
      }
    }

    /* read eigenvector_invers */
    //etb[iatom].evect_invers = (double ***)calloc_3d_array(nte_c, nstat, nstat, sizeof(double));
    etb[iatom].evect_invers = (double ***)calloc(nte_c, sizeof(double**));
    for (k = 0; k < nte_c; k++) {
      etb[iatom].evect_invers[k] = (double **)calloc(nstat, sizeof(double*));
      for (j = 0; j < nstat; j++) {
        etb[iatom].evect_invers[k][j] = (double *)calloc(nstat, sizeof(double));
      }
    }
    for (i = 0; i < nstat; i++) {
      for (j = 0; j < nstat; j++) {
        for (k = 0; k < nte_c; k++) {
          fscanf(fp, "%lf", &temp);
          etb[iatom].evect_invers[k][j][i] = temp;
        }
      }
    }

    fclose(fp);
  }
  return;
}

/*-----------------------------------------------------------------------------
  function: sub_read_rltable
  ----------------------------------------------------------------------------*/
void sub_read_rltable(char cooling_table_datapath[])
{
  // Define path
  FILE *fp;
  char filename[500];
  char* coolingtable_datapath;

  /* Get cooling table path */
  //coolingtable_datapath = par_gets("NEI", "coolingtable_datapath");

  // Enter the element loop
  int i, ielem, iz, nte;
  double var;
  for (ielem=0; ielem<n_coolingelem; ielem++) {
    iz = natom_cooling_list[ielem];
    // Get file name
    sprintf(filename, "%s%s_radloss.dat", cooling_table_datapath, coolingelem_list[ielem]);
    printf("  reading: %s\n", filename);

    // Open file
    fp = fopen(filename, "r");

    // Read constant
    fscanf(fp, "%d", &iz);
    rlrate[ielem].natom = iz;
    
    fscanf(fp, "%d", &nte);
    rlrate[ielem].nte = nte;
    
    fscanf(fp, "%le", &var);
    rlrate[ielem].abundance = var;
    
    // Read 1D temperature grid
    rlrate[ielem].temperature = (double *)calloc(nte, sizeof(double));
    for (i=0; i<nte; i++) {
        fscanf(fp, "%le", &var);
        rlrate[ielem].temperature[i] = var;
    }

    // Read 1D radloss in EI cases
    rlrate[ielem].rate_ei = (double *)calloc(nte, sizeof(double));
    for (i=0; i<nte; i++) {
        fscanf(fp, "%le", &var);
        rlrate[ielem].rate_ei[i] = var;
    }

    // Read 2D EI fraction and rate
    int ite, iion, nstate;
    nstate = iz+1;
    //rlrate[ielem].eifraction = (double **)calloc_2d_array(nstate,nte,sizeof(double));
    //rlrate[ielem].rate2d = (double **)calloc_2d_array(nstate,nte,sizeof(double));
    rlrate[ielem].eifraction = (double **)calloc(nstate, sizeof(double*));
    for (iion = 0; iion < nstate; iion++) {
      rlrate[ielem].eifraction[iion] = (double *)calloc(nte, sizeof(double));
    }
    rlrate[ielem].rate2d = (double **)calloc(nstate, sizeof(double*));
    for (iion = 0; iion < nstate; iion++) {
      rlrate[ielem].rate2d[iion] = (double *)calloc(nte, sizeof(double));
    }

    for (ite=0;ite<nte;ite++){
      for (iion=0;iion<nstate;iion++) {
        fscanf(fp, "%le", &var);
        rlrate[ielem].eifraction[iion][ite] = var;
      }
    }
    for (ite=0;ite<nte;ite++){
      for (iion=0;iion<nstate;iion++) {
        fscanf(fp, "%le", &var);
        rlrate[ielem].rate2d[iion][ite] = var;
        //printf("%le \n", rlrate[ielem].rate2d[iion][ite]);
      }
    }
    // close file
    fclose(fp);
  }

  // Get sum of cooling rate in EI cases
  qtarray = (double *)calloc(nte, sizeof(double));
 	for (ielem=0; ielem<n_coolingelem; ielem++) {
 		for (i=0; i<nte; i++) {
 			qtarray[i] += rlrate[ielem].rate_ei[i];
 		}
  }

  return;
}

/*----------------------------------------------------------------------------
  function: func_qt_ei(temperature)
  ----------------------------------------------------------------------------*/
double func_qt_ei(const double te)
{
  double qt;

  // Perform interpolation
  double rate_l, rate_r;
  int ite_l = (int)((log10(te) - const_dlogte_low)/const_dlogte_grid);
  int ite_r = ite_l+1;
  double ratio = (log10(te) - log10(rlrate[0].temperature[ite_l]))
    /(log10(rlrate[0].temperature[ite_r]) - log10(rlrate[0].temperature[ite_l]));

  rate_l = qtarray[ite_l];
  rate_r = qtarray[ite_r];
  qt = ratio*(rate_r - rate_l) + rate_l;
  return qt;
}

