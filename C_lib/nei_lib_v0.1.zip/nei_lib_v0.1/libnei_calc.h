/* Global variables */
extern int elemmax;
extern int nelem, *elem_list, *ion_sindex_list;

/* NEI_calc functinos */
void ini_table(char str_natomlist[],
               char ionrec_table_datapath[],
               char cooling_table_datapath[],
               const int n_scalar); 
void read_eigentb(char ionrec_table_datapath[]);
void sub_read_rltable(char cooling_table_datapath[]);
void ini_ionfraction(const int npoints, const double te_k_list[],
                              double **conce_out);
void nei_advance(const int npoints,
                     const int nstates_total,
                     const double te_k_pre[],
                     const double te_k_cur[],
                     const double ne_cm_pre[],
                     const double ne_cm_cur[],
                     double **conce_in,
                     const double dt,
                     double **conce_out);
void qtcell_nei(const int npoints,
                       const double te_k_list[],
                       double **conce_in,
                       double *qtcell);
double func_qt_ei(const double te);
