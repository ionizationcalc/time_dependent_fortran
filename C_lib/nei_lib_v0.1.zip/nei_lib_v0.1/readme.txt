#
# This routine is used to perform the in-line time-dependent ionization calculation in HD/MHD simulations using Athena code.
#
# Update: 2021-08
#         2021-10: Works with Intel compiler V2020 and MKL libs

#
# 1. Compile it with the intel MKL libraries. 
#
# You may run the following commands on the supercomputer (e.g., SI/Hydra cluster) to get compilers and all dependent libs:
module load intel/2019.5

# Then compile the source code and create static libs:
icc -c -I${MKL_ROOT}/include/intel64/lp64/ -L${MKL_ROOT}/lib/intel64 -lmkl_lapack95_lp64 -lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core  -liomp5 -lpthread nei_calc.c -o libnei_calc.o

ar rcs libnei_calc.a libnei_calc.o

# Change it to readable:
chmod +x libnei_calc.a


#
# 2. Add the "include/linker path" and the "libnei_calc" file to the project Makefile
#
# For instance, edit 'Makeoptions.in' in the root folder of the Athena code and add the following:
LDFLAG = -L$(MKL_ROOT)/lib/intel64 -L/your_path_to_this_nei_lib
MPIINC = -I$(MKL_ROOT)/include -I/your_path_to_this_nei_lib
MPILIB = $(LDFLAG) -lmkl_lapack95_lp64 -lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core  -liomp5 -lpthread -lnei_calc

In this example, "-I/your_path_to_this_nei_lib" is used to define the local 'include path' to search libnei_calc.h file.
"-L/your_path_to_this_nei_lib" defines the local linker path, and "-lnei_calc" defines the particular linker file name.
The other flags are for intel MKL relevant library files, which can be in different forms depending on your environment.

#
# 3. Call functions in your project
#
This module calculates ionic population evolution during the particular time-step for all chosen chemical elements (see Shen, Raymond & Murphy, A&C, 2015 in details).
(a) Initialize the ion fraction at the beginning of MHD simulations;

(b) call NEI routines in the User-in-loop section of the Athena code.

#
# 4. Examples
#
See the attached 1d-shock tub simulations.
